﻿## Benchmark Results

- 1P1C
```
SeqNum: 4642181450, ProducerId: 1, t0: 1744552084925273, latencyUs: 1, maxLatencyUs (percentile:98.9): 9, msgCount/sec: 8,950,270
SeqNum: 4689324165, ProducerId: 1, t0: 1744552089925266, latencyUs: 9, maxLatencyUs (percentile:98.9): 9, msgCount/sec: 9,428,543
SeqNum: 4744184121, ProducerId: 1, t0: 1744552094925271, latencyUs: 5, maxLatencyUs (percentile:98.9): 9, msgCount/sec: 10,971,991
SeqNum: 4800254100, ProducerId: 1, t0: 1744552099925273, latencyUs: 4, maxLatencyUs (percentile:98.9): 9, msgCount/sec: 11,213,995
SeqNum: 4854746052, ProducerId: 1, t0: 1744552104925277, latencyUs: 1, maxLatencyUs (percentile:98.9): 9, msgCount/sec: 10,898,390
SeqNum: 4909356957, ProducerId: 1, t0: 1744552109925278, latencyUs: 1, maxLatencyUs (percentile:99.0): 9, msgCount/sec: 10,922,181
SeqNum: 4964828466, ProducerId: 1, t0: 1744552114925278, latencyUs: 2, maxLatencyUs (percentile:99.0): 9, msgCount/sec: 11,094,301
SeqNum: 5020856924, ProducerId: 1, t0: 1744552119925280, latencyUs: 1, maxLatencyUs (percentile:99.0): 9, msgCount/sec: 11,205,691
SeqNum: 5074874963, ProducerId: 1, t0: 1744552124925281, latencyUs: 1, maxLatencyUs (percentile:99.0): 9, msgCount/sec: 10,803,607
SeqNum: 5123924998, ProducerId: 1, t0: 1744552129925282, latencyUs: 1, maxLatencyUs (percentile:99.0): 9, msgCount/sec: 9,810,007
SeqNum: 5172037771, ProducerId: 1, t0: 1744552134925283, latencyUs: 1, maxLatencyUs (percentile:99.0): 9, msgCount/sec: 9,622,554
SeqNum: 5220418890, ProducerId: 1, t0: 1744552139925284, latencyUs: 1, maxLatencyUs (percentile:99.0): 9, msgCount/sec: 9,676,223
SeqNum: 5268863337, ProducerId: 1, t0: 1744552144925285, latencyUs: 1, maxLatencyUs (percentile:99.0): 9, msgCount/sec: 9,688,889
SeqNum: 5316573264, ProducerId: 1, t0: 1744552149925286, latencyUs: 1, maxLatencyUs (percentile:99.0): 9, msgCount/sec: 9,541,985
SeqNum: 5364165980, ProducerId: 1, t0: 1744552154925287, latencyUs: 1, maxLatencyUs (percentile:99.0): 9, msgCount/sec: 9,518,543
SeqNum: 5414516657, ProducerId: 1, t0: 1744552159925284, latencyUs: 5, maxLatencyUs (percentile:99.1): 9, msgCount/sec: 10,070,135
```
- 4P1C
```
SeqNum: 6892738466, ProducerId: 2, t0: 1744546013230231, latencyUs: 6, maxLatencyUs (percentile:99.8): 13, msgCount/sec: 8,453,915
SeqNum: 6912958704, ProducerId: 3, t0: 1744546018230237, latencyUs: 1, maxLatencyUs (percentile:99.8): 13, msgCount/sec: 8,445,109
SeqNum: 6923696648, ProducerId: 3, t0: 1744546023230238, latencyUs: 1, maxLatencyUs (percentile:99.8): 13, msgCount/sec: 8,458,433
SeqNum: 6893465938, ProducerId: 0, t0: 1744546028230234, latencyUs: 6, maxLatencyUs (percentile:99.8): 13, msgCount/sec: 8,438,795
SeqNum: 6899327271, ProducerId: 1, t0: 1744546033230237, latencyUs: 4, maxLatencyUs (percentile:99.8): 13, msgCount/sec: 8,430,389
SeqNum: 6945137211, ProducerId: 2, t0: 1744546038230252, latencyUs: 0, maxLatencyUs (percentile:99.8): 13, msgCount/sec: 8,431,688
SeqNum: 6955855117, ProducerId: 2, t0: 1744546043230252, latencyUs: 1, maxLatencyUs (percentile:99.8): 13, msgCount/sec: 8,421,218
SeqNum: 6966562728, ProducerId: 2, t0: 1744546048230253, latencyUs: 1, maxLatencyUs (percentile:99.8): 13, msgCount/sec: 8,434,139
SeqNum: 6977206352, ProducerId: 2, t0: 1744546053230246, latencyUs: 9, maxLatencyUs (percentile:99.8): 13, msgCount/sec: 8,457,423
SeqNum: 6987547623, ProducerId: 2, t0: 1744546058230253, latencyUs: 3, maxLatencyUs (percentile:99.8): 13, msgCount/sec: 8,416,810
SeqNum: 7008107755, ProducerId: 3, t0: 1744546063230252, latencyUs: 5, maxLatencyUs (percentile:99.8): 13, msgCount/sec: 8,455,167
SeqNum: 6971946661, ProducerId: 1, t0: 1744546068230252, latencyUs: 6, maxLatencyUs (percentile:99.8): 13, msgCount/sec: 8,387,359
SeqNum: 7019162874, ProducerId: 2, t0: 1744546073230254, latencyUs: 5, maxLatencyUs (percentile:99.8): 13, msgCount/sec: 8,414,146
SeqNum: 7039216107, ProducerId: 3, t0: 1744546078230252, latencyUs: 8, maxLatencyUs (percentile:99.9): 13, msgCount/sec: 8,348,738
SeqNum: 7003957668, ProducerId: 1, t0: 1744546083230260, latencyUs: 1, maxLatencyUs (percentile:99.9): 13, msgCount/sec: 8,376,267
SeqNum: 7013894247, ProducerId: 1, t0: 1744546088230269, latencyUs: 0, maxLatencyUs (percentile:99.9): 13, msgCount/sec: 8,425,523
SeqNum: 7071230548, ProducerId: 3, t0: 1744546093230264, latencyUs: 6, maxLatencyUs (percentile:99.9): 13, msgCount/sec: 8,401,697
SeqNum: 7041178742, ProducerId: 0, t0: 1744546098230263, latencyUs: 8, maxLatencyUs (percentile:99.9): 13, msgCount/sec: 8,454,937
```